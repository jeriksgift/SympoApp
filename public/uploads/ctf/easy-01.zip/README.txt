Spider Society Intelligence

Kingpin's message has been intercepted.

The message has been encrypted using a classical cipher.

Decode the message and submit the flag.

Flag Format:
SPIDER{decoded_message}
